import React from "react";
import { StyleSheet, Text, View, Image } from "react-native";
import { AppScreen } from "../AppScreen";
import { Button, TextInput } from 'react-native-paper'


const LoginScreen = ({ navigation }) => {
    return (
        <AppScreen style={styles.screen}>
            <Text style={{ fontSize: 30, fontWeight: "bold", padding: 10 }}>Apple Hub</Text>
            <Image source={{
                width: 100,
                height: 100,
                uri: "https://images.unsplash.com/photo-1621768216002-5ac171876625?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8YXBwbGUlMjBsb2dvfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
            }} />
            <View style={styles.form}>
                <TextInput mode="outlined" label="Username" />
                <TextInput mode="outlined" label="Password" />
                <Button color="#607D88" icon="email" mode="contained" style={{ padding: 10, marginVertical: 10 }} onPress={() => navigation.navigate("Home")}  >Login</Button>
                <Button color="#607D88" icon="email" mode="contained" style={{ padding: 10, marginVertical: 10 }} onPress={() => navigation.navigate("Home")}  >Register</Button>
            </View>
        </AppScreen>
    )
}

export default LoginScreen

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    },
    form: {
        padding: 5,
        width: "100%",
        backgroundColor: "black",
        borderRadius: 10
    }
})