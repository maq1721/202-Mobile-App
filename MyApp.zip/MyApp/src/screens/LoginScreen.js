import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { AppScreen } from "../AppScreen";
import { Button, TextInput } from 'react-native-paper'


const LoginScreen = ({ navigation }) => {
    return (
        <AppScreen style={styles.screen}>
            <View style={styles.form}>
                <TextInput mode="outlined" label="e-Mail" />
                <TextInput mode="outlined" label="Password" />
                <Button color="#607D88" icon="email" mode="contained" style={{ padding: 10, marginVertical: 10 }} onPress={() => navigation.navigate("Home")}  >Login</Button>
            </View>
        </AppScreen>
    )
}

export default LoginScreen

const styles = StyleSheet.create({
    screen: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    },
    form: {
        padding: 10,
        width: "100%",
        backgroundColor: "black",
        borderRadius: 10
    }
})