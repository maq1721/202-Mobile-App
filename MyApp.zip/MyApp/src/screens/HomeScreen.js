import React, { useContext } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { ProductContext } from '../Context/Product.context';
import { ActivityIndicator } from 'react-native-paper';
import { AppCard } from '../components/AppCard/AppCard'
import { AppScreen } from '../AppScreen';

const HomeScreen = ({ navigation }) => {

    const { isLoading, product } = useContext(ProductContext)

    if (isLoading) {
        return (
            <View style={styles.prodLoading}>
                <ActivityIndicator animating={true} size="large" />
                <Text style={{ marginVertical: 10 }}>Loading Products</Text>
            </View>
        )
    }


    return (
        <AppScreen>
            <View>
                <FlatList vertical showsVerticalScrollIndicator={false}
                    data={product} keyExtractor={(item) => item.id}
                    renderItem={({ item }) => <AppCard title={item.title}
                        price={item.price}
                        image={item.image}
                        items={item}
                        onPress={() => navigation.navigate("Details", { product: item })}

                    />} />
            </View>
        </AppScreen>
    )
}

export default HomeScreen

const styles = StyleSheet.create({
    prodLoading: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    }
})