import React, { useContext } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button, List } from 'react-native-paper';
import { ScrollView } from 'react-native-gesture-handler';
import { AppScreen } from '../AppScreen';
import { AppCard } from '../components/AppCard/AppCard';
import { useDispatch } from 'react-redux';
import { cartActions } from '../redux/cart.redux';
import { ProductContext } from '../Context/Product.context';

const DetailsScreen = ({ route }) => {

    const { product } = route.params

    const dispatch = useDispatch()

    const addTocart = () => {
        dispatch(cartActions.addtoCart(product))
    }



    return (
        <AppScreen>
            <ScrollView>
                <View>
                    <AppCard style={styles.card} imgContainer={styles.imgContainer} title={product.title} price={product.price} image={product.image} items={product} />
                </View>
                <View style={styles.btnContainer}>
                    <Button icon="shopping" color="#263238" onPress={addTocart} mode="contained" style={styles.btn}>Add To Cart</Button>
                </View>
                <List.Section title={'Product Details'}>
                    <List.Accordion title="Product Information" left={() => <List.Icon icon="information" />}>
                        <List.Item description={product.description} />
                    </List.Accordion>
                    <List.Accordion title="Ratings" left={() => <List.Icon icon="star" />}>
                        <List.Item title="5/5" />
                    </List.Accordion>
                </List.Section>
            </ScrollView>
        </AppScreen>
    )
}

export default DetailsScreen

const styles = StyleSheet.create({
    card: {
        backgroundColor: "#263238",
        width: "100%",
        marginHorizontal: 0,
        borderRadius: 5
    },
    imgContainer: {
        height: 330
    },
    btnContainer: {
        padding: 10
    },
    btn: {
        padding: 10
    }
})