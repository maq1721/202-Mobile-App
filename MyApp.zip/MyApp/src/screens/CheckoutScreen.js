import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { SafeAreaView, Button, StyleSheet, Text, View, Alert, Image } from 'react-native';
import { useStripe } from '@stripe/stripe-react-native';
import { TextInput } from 'react-native-paper'

const CheckoutScreen = () => {

    const [clientSecret, setClientSecret] = useState()

    const { initPaymentSheet, presentPaymentSheet } = useStripe()

    useEffect(() => {
        initializePayment()
    }, [])
    const initializePayment = async () => {
        try {
            const response = await fetch('', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    paymentMethod: "card",
                    currency: "GH₵",
                    amount: 10000
                })
            })

            const { client_secret } = await response.json()
            setClientSecret(client_secret)

            const { error } = await initPaymentSheet({
                paymentIntentClientSecret: clientSecret
            })
            if (!error) {
                Alert.alert('ERROR CODE', error.code)
            }


        } catch (error) {
            console.log(error.message);
        }
    }

    const openPaymentSheet = async () => {
        try {

            const { error } = await presentPaymentSheet({
                clientSecret: clientSecret
            })
            if (error) {
                Alert.alert('PAYMENT FAILED', error.message)
            }
            else {
                Alert.alert('SUCCESS', 'PAYMENT SUCCESSFUL...')
            }

        } catch (error) {
            console.log(error.message);
        }
    }

    return (
        <SafeAreaView style={styles.screen}>
            <View>
                <Text style={styles.payment}>Pay With Mobile Money</Text>
                <Text style={styles.vendor}>From All Vendors!</Text>
                <Image source={{
                    width: 375,
                    height: 200,
                    uri: "https://cdn.modernghana.com/content/600/360/11282019103625-i41p266gfa-momo.jpg"
                }} />
                <TextInput mode="outlined" label="Phone Number" />
                <TextInput mode="outlined" label="PIN" />
                <Text style={styles.ship}>Shipping Details</Text>
                <TextInput mode="outlined" label="Full Name" />
                <TextInput mode="outlined" label="Address Details" />
                <Button color="black" title="PAY NOW" onPress={() => Alert.alert('Payment Succesful')} />
            </View>
        </SafeAreaView>
    )
}

export default CheckoutScreen

const styles = StyleSheet.create({
    screen: {
        marginTop: StatusBar.currentHeight
    },
    payment: {
        fontSize: 25,
        textAlign: 'center',
        fontWeight: 'bold'
    },
    vendor: {
        padding: 5,
        textAlign: 'center'
    },
    ship: {
        fontSize: 15,
        textAlign: 'center',
        padding: 5,
        fontWeight: 'bold'
    }
})