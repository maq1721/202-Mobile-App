import React from "react";
import { View, StyleSheet, Text } from "react-native";
import { Button } from "react-native-paper";
import { AppScreen } from "../AppScreen";

export const MainWelcomeScreen = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <AppScreen style={styles.screen}>
                <View style={styles.appTitle}>
                    <Text style={styles.titleText}>Welcome</Text>
                </View>
                <View style={styles.btnsContainer}>
                    <Button style={styles.btn} color="#607D88" mode="contained" icon="email" onPress={() => navigation.navigate("Login")}>Login</Button>
                    <Button style={styles.btn} color="#263238" mode="contained" onPress={() => navigation.navigate("Register")}>Register</Button>
                </View>
            </AppScreen>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    screen: {
        justifyContent: 'center',
        alignItems: "center"
    },
    btnsContainer: {
        padding: 10,
        width: '100%',
        backgroundColor: "black"
    },
    btn: {
        padding: 10,
        marginVertical: 10
    },
    appTitle: {
        marginVertical: 20
    },
    titleText: {
        fontSize: 26,
        fontWeight: "500",
    }
})