import React from "react";
import { View, StyleSheet, Text, Image } from "react-native";
import { Button } from "react-native-paper";
import { AppScreen } from "../AppScreen";

export const MainWelcomeScreen = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <AppScreen style={styles.screen}>
                <View style={styles.appTitle}>
                    <Text style={{ fontSize: 30, fontWeight: "bold", padding: 10, marginLeft: 68 }}>Apple Hub</Text>
                    <Image source={{
                        width: 300,
                        height: 300,
                        uri: "https://images.unsplash.com/photo-1621768216002-5ac171876625?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8YXBwbGUlMjBsb2dvfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                    }} />
                </View>
                <View style={styles.btnsContainer}>
                    <Button style={styles.btn} color="#607D88" mode="contained" icon="email" onPress={() => navigation.navigate("Login")}>Login</Button>
                    <Button style={styles.btn} color="#263238" mode="contained" onPress={() => navigation.navigate("Register")}>Register</Button>
                </View>
            </AppScreen>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    screen: {
        justifyContent: 'center',
        alignItems: "center"
    },
    btnsContainer: {
        padding: 10,
        width: '100%',
        backgroundColor: "black"
    },
    btn: {
        padding: 10,
        marginVertical: 10
    },
    appTitle: {
        marginVertical: 20
    },
    titleText: {
        fontSize: 26,
        fontWeight: "500",
    }
})