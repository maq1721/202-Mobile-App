import React, { useContext } from "react"
import { TouchableOpacity, StyleSheet } from "react-native"
import { AntDesign } from '@expo/vector-icons'
import { FavouriteContext } from "../../Context/Favourite.context"

export const Favourite = () => {

    const favs = useContext(FavouriteContext)
    console.log(favs)

    return (
        <TouchableOpacity style={styles.favs}>
            <AntDesign size={30} color="red" name="hearto" />
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    favs: {
        position: "absolute",
        left: 10,
        top: 5,
        zIndex: 100
    }
})