import React from 'react'
import { Image, Text, TouchableOpacity, View, StyleSheet } from 'react-native'
import { AntDesign } from '@expo/vector-icons'
import { Favourite } from '../Favourites/Favourites'

export const AppCard = ({ title, price, image, items, onPress }) => {
    return (
        <TouchableOpacity onPress={onPress} style={styles.card}>

            <Favourite product={items} />

            <View style={styles.imageContainer}>
                <Image source={{ uri: image }} style={{ height: "100%", width: "100%" }} />
            </View>

            <View style={styles.cardBody}>
                <View style={styles.cardContent}>
                    <Text style={styles.title}>{title}</Text>
                    <Text style={styles.price}>{price}</Text>
                </View>
                <View style={{ flexDirection: "row" }}>
                    <AntDesign name="star" size={18} color="orange" />
                    <AntDesign name="star" size={18} color="orange" />
                    <AntDesign name="star" size={18} color="orange" />
                    <AntDesign name="star" size={18} color="orange" />
                    <AntDesign name="star" size={18} color="orange" />
                </View>
            </View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    card: {
        width: 375,
        backgroundColor: "aliceblue",
        paddingBottom: 10,
    },
    imageContainer: {
        height: 200,
    },
    cardBody: {
        padding: 10,
    },
    cardContent: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginVertical: 5
    },
    title: {
        fontSize: 20,
        fontWeight: "500"
    },
    price: {
        fontSize: 24,
        fontWeight: "bold"
    }
})