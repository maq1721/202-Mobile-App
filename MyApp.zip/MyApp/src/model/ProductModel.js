export const data = [
    {
        title: "Apple iPhone 13",
        price: "GH₵ 6299",
        id: "129",
        image: "https://images.unsplash.com/photo-1634618774328-613d0f997911?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Apple's newest flagship iPhone on the more affordable end."
    },

    {
        title: "Apple AirPods Pro",
        price: "GH₵ 1499",
        id: "12d9",
        image: "https://images.unsplash.com/photo-1593442607435-e4e34991b210?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=885&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Features Active Noise Cancellation, Transparency mode, and a customizable fit for all-day comfort."
    },

    {
        title: "Apple Watch Series 6",
        price: "GH₵ 3199",
        id: "157.87",
        image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=764&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Offers fast charging, completing a full charge in under 1.5 hours, and improved battery life."
    },

    {
        title: "Apple iPad Pro 12.9",
        price: "GH₵ 8499",
        id: "157e4",
        image: "https://images.unsplash.com/photo-1587033411391-5d9e51cce126?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1074&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Apple's high-end tablet computer."


    },

    {
        title: "Apple MacBook",
        price: "GH₵ 9999",
        id: "128.32",
        image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1120&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "MacBook Air is a thin, lightweight laptop from Apple."
    },

    {
        title: "Apple iPhone 12",
        price: "GH₵ 5999",
        id: "128.31",
        image: "https://images.unsplash.com/photo-1607937782128-1a249f7347e8?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "The iPhone 12 is part of Apple's 2020 generation of smartphones"
    },

    {
        title: "Apple HomePod",
        price: "GH₵ 2139",
        id: "128.531",
        image: "https://media.istockphoto.com/photos/black-and-white-smart-speakers-3d-rendering-isolated-on-white-picture-id1056477422?b=1&k=20&m=1056477422&s=170667a&w=0&h=F4IquPG0uw1q6rPqm9z_ZUobUSQwV4lUrRX_hia8yck=",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "A Siri virtual assistant and wireless speaker from Apple."
    },

    {
        title: "Apple TV",
        price: "GH₵ 1829",
        id: "128.5891",
        image: "https://images.unsplash.com/photo-1621685950846-9323d993bbf3?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Apple TV is a set-top box that allows a television to become a display screen for Internet content."
    },

    {
        title: "Apple iPhone XR",
        price: "GH₵ 2569",
        id: "128.58451",
        image: "https://images.unsplash.com/photo-1605161702560-995aeda17042?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1170&q=80",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "Features a 32 percent larger sensor than the iPhone X."
    },

    {
        title: "Apple MagSafe Charger",
        price: "GH₵ 399",
        id: "128.5845",
        image: "https://i5.walmartimages.com/asr/2683b1b3-0c25-460e-b994-5c80cf11dc96.90c20176134672c2f7f1646d39ce1a66.jpeg",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "The MagSafe Charger is designed to quickly and safely wirelessly charge your iPhone."
    },

    {
        title: "Apple iPhone X",
        price: "GH₵ 1869",
        id: "128.58451",
        image: "https://images.unsplash.com/photo-1511227682637-ddb98c43c42c?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fGlwaG9uZSUyMHh8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        brand: "Apple",
        colors: ["#00e0ff", "#f9ff21", "#107a8b", "#d72323"],
        description: "The iPhone X contains Apple's A11 Bionic system-on-chip."
    },
]