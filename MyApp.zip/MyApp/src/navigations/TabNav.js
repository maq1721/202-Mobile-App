import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import HomeScreen from '../screens/HomeScreen';
import CartScreen from '../screens/CartScreen';
import UserScreen from '../screens/UserScreen'
import CheckoutScreen from '../screens/CheckoutScreen';
import { AntDesign } from '@expo/vector-icons'
import { StackNav } from './StackNav';
import { stackNavII } from './stackNavII';

const Tab = createBottomTabNavigator()

const TabIcons = {
    User: "user",
    Home: "home",
    Cart: "shoppingcart",
}


export const TabNav = () => {
    return (
        <Tab.Navigator tabBarOptions={{ showLabel: false }} screenOptions={({ route }) => ({
            tabBarIcon: ({ size, color }) => {
                const iconName = TabIcons[route.name]
                return <AntDesign name={iconName} size={size} color={color} />
            }
        })}>
            <Tab.Screen name="Home" component={StackNav} />
            <Tab.Screen name="Cart" component={stackNavII} />
        </Tab.Navigator>
    )
}