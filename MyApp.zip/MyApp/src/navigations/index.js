import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { TabNav } from './TabNav';
import { AuthNav } from './AuthNav';
import { StackNav } from './StackNav';

export const AppNavigation = () => {
    return (
        <NavigationContainer>
            <AuthNav />
        </NavigationContainer>
    )
}
