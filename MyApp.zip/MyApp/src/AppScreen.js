import React from 'react'
import { SafeAreaView, StyleSheet } from 'react-native'

export const AppScreen = ({ style, children }) => {
    return (
        <SafeAreaView style={[styles.screen, { ...style }]}>
            {children}
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    screen: {
        marginTop: 5
    }
})