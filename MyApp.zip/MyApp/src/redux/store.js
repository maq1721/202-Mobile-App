import { configureStore } from '@reduxjs/toolkit'
import { cartSlice } from './cart.redux'

export const store = configureStore({
    reducer: {
        cart: cartSlice.reducer
    }
})