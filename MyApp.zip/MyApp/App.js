import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { FavouriteContextProvider } from './src/components/Favourites/Favourites';
import { ProductContextProvider } from './src/Context/Product.context';
import { AppNavigation } from './src/navigations';
import { Provider } from 'react-redux';
import { store } from './src/redux/store';

const App = () => {
  return (
    <Provider store={store}>
      <ProductContextProvider>
        <AppNavigation />
      </ProductContextProvider>
    </Provider>
  )
}

export default App